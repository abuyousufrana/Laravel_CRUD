<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
 
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        <h2>Dashboard Crud</h2>
                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(route('course.index')); ?>" class="btn btn-success btn-sm" title="Add New Student">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New Courses
                        </a>
                        <br/>
                        <br/>
 
                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(route('teacher.index')); ?>" class="btn btn-success btn-sm" title="Add New Student">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New Teacher
                        </a>
                        <br/>
                        <br/>
 
                    </div>
                    <div class="card-body">
                        <a href="<?php echo e(route('student.index')); ?>" class="btn btn-success btn-sm" title="Add New Student">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New Student
                        </a>
                        <br/>
                        <br/>
 
                    </div>

                    <div class="card-body">
                        <a href="" class="btn btn-success btn-sm" title="Add New Student">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New Print
                        </a>
                        <br/>
                        <br/>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel Project\New_Crud\resources\views/welcome.blade.php ENDPATH**/ ?>