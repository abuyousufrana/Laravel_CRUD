
<?php $__env->startSection('content'); ?>
 
<div class="card">
  <div class="card-header">course Page</div>
  <div class="card-body">
      
      <form action="<?php echo e(route('course.store')); ?>" method="post">
        <?php echo csrf_field(); ?>

        <label>Name</label></br>
        <input type="text" name="name" id="name" class="form-control"></br>
        <!-- <label>Teacher Name</label></br>
        <input type="text" name="teacher_name" id="teacher_name" class="form-control"></br> -->
        <label>Fees</label></br>
        <input type="text" name="fees" id="fees" class="form-control"></br>
        <label>Teacher Name<span class="required">*</span></label>
                        <select name="teacher_name" id="teacher_name" class="form-control" required>
                            <option selected disabled>Select Name</option>
                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cou): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>;
                                <option value="<?php echo e($cou->name); ?>"><?php echo e($cou->name); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>;
                        </select>
        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('students.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel Project\New_Crud\resources\views/courses/create.blade.php ENDPATH**/ ?>