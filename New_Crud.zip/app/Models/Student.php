<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Student extends Model
{
    use HasFactory;
    protected $table = 'students';
    protected $primaryKey = 'id';
    protected $fillable = ['name', 'address', 'course', 'mobile'];

    public static function student_list(){
        return DB::table('students')->select('students.*','courses.name as course_name')->join('courses','students.course','=','courses.id')->get();
    }

    public function courseName()
    {
        return $this->belongsTo(Course::class, 'student_id', 'íd');
    }
}
