@extends('students.layout')
@section('content')
 
<div class="card">
  <div class="card-header">course Page</div>
  <div class="card-body">
      
      <form action="{{ route('course.store') }}" method="post">
        {!! csrf_field() !!}
        <label>Name</label></br>
        <input type="text" name="name" id="name" class="form-control"></br>
        <!-- <label>Teacher Name</label></br>
        <input type="text" name="teacher_name" id="teacher_name" class="form-control"></br> -->
        <label>Teacher Name<span class="required">*</span></label>
                        <select name="teacher_name" id="teacher_name" class="form-control" required>
                            <option selected disabled>Select Name</option>
                            @foreach ($teachers as $cou);
                                <option value="{{$cou->name}}">{{$cou->name}}</option>
                             @endforeach;
                        </select>
        <label>Fees</label></br>
        <input type="text" name="fees" id="fees" class="form-control"></br>
        <input type="submit" value="Save" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
 
@stop