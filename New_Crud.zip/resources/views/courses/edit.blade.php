@extends('students.layout')
@section('content')
 
<div class="card">
  <div class="card-header">Contactus Page</div>
  <div class="card-body">
      
      <form action="{{ route('course.update') }}" method="post">
        @csrf
        <input type="hidden" name="id" id="id" value="{{$courses->id}}" id="id" />
        <label>Name</label></br>
        <input type="text" name="name" id="name" value="{{$courses->name}}" class="form-control"></br>
        <label>Teacher Name</label></br>
        <input type="text" name="teacher_name" id="teacher_name" value="{{$courses->teacher_name}}" class="form-control"></br>
        <label>Fees</label></br>
        <input type="text" name="fees" id="fees" value="{{$courses->fees}}" class="form-control"></br>

        <input type="submit" value="Update" class="btn btn-success"></br>
    </form>
   
  </div>
</div>
 
@stop